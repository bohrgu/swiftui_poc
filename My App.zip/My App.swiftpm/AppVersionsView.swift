import SwiftUI

struct AppVersionsView: View {
    @State private var appVersions = [AppVersion]()
    
    var body: some View {
        List(appVersions, id: \.key) { item in
            VStack(alignment: .leading) {
                Text(item.key)
                    .font(.headline)
                Text(item.value)
            }
        }
        .task {
            await loadData()
        }
    }
    
    func loadData() async {
        guard let url = URL(string: "https://api.lyf.eu/public/api/appVersions") else {
            print("Failed to generate URL")
            return
        }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            if let decodedResponse = try? JSONDecoder().decode(Response.self, from: data) {
                print(decodedResponse)
                appVersions = decodedResponse.parameters
            }
        }
        catch {
            print("Failed to get data from URL")
            return
        }
    }
}
