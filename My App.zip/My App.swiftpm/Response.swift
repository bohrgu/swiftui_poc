import Foundation

struct Response: Codable {
    var returnCode: Int
    var available: Int
    var count: Int
    var message: String
    var parameters: [AppVersion]
}

struct AppVersion: Codable {
    var key: String
    var value: String
}
