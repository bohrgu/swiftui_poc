import SwiftUI

class Webservice: Any {
    func call(completion: @escaping (_ data: Any?, _ error: String?) -> Void) {
        let defaultSession = URLSession(configuration: .default)
        var dataTask: URLSessionDataTask?
        // 1
        dataTask?.cancel()
        
        // 2
        if let urlComponents = URLComponents(string: "https://api.lyf.eu/public/api/appVersions") {
            // 3
            guard let url = urlComponents.url else {
                return
            }
            // 4
            dataTask = 
            defaultSession.dataTask(with: url) { [weak self] data, response, error in 
                defer {
                    dataTask = nil
                }
                // 5
                if let error = error {
                    var errorMessage = "DataTask error: " + error.localizedDescription + "\n"
                    print(errorMessage)
                    completion(nil, errorMessage)
                } else if 
                    let data = data, let response = response as? HTTPURLResponse,
                    response.statusCode == 200 {
                    do {
                        let json = try JSONSerialization.jsonObject(with: data, options: [.allowFragments])
                        print(json)
                        completion(json, nil)
                    }
                    catch {
                        let errorMessage = "Failed to catch JSON object"
                        print(errorMessage)
                        completion(nil, errorMessage)
                    }
                }
            }
            // 7
            dataTask?.resume()
        }
    }
}


