import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            VStack {
                NavigationLink("Voir appel webservice") {
                    AppVersionsView()
                }
            }
        }.navigationTitle("Navigation")
    }
}

struct ActionView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Button("Appeler webservice") {
                let ws = Webservice()
                ws.call { data, error in
                    DispatchQueue.main.async {
//                        let alert = UIAlertController(title: "My Alert", message: "This is an alert.", preferredStyle: .alert)
//                        alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
//                            NSLog("The \"OK\" alert occured.")
//                        }))
//                        UIApplication.shared.windows.first?.rootViewController?.presentedViewController?.present(alert, animated: true, completion: nil)
                    }
                }
            }
        }
    }
}
